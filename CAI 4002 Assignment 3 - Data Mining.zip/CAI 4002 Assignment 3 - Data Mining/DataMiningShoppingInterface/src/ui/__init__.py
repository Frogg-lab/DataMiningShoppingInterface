"""UI package for DataMiningShoppingInterface."""
